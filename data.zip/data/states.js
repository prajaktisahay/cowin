module.exports = [
  {
    "value": 1,
    "name": "Andaman and Nicobar Islands"
  },
  {
    "value": 2,
    "name": "Andhra Pradesh"
  },
  {
    "value": 3,
    "name": "Arunachal Pradesh"
  },
  {
    "value": 4,
    "name": "Assam"
  },
  {
    "value": 5,
    "name": "Bihar"
  },
  {
    "value": 6,
    "name": "Chandigarh"
  },
  {
    "value": 7,
    "name": "Chhattisgarh"
  },
  {
    "value": 8,
    "name": "Dadra and Nagar Haveli"
  },
  {
    "value": 37,
    "name": "Daman and Diu"
  },
  {
    "value": 9,
    "name": "Delhi"
  },
  {
    "value": 10,
    "name": "Goa"
  },
  {
    "value": 11,
    "name": "Gujarat"
  },
  {
    "value": 12,
    "name": "Haryana"
  },
  {
    "value": 13,
    "name": "Himachal Pradesh"
  },
  {
    "value": 14,
    "name": "Jammu and Kashmir"
  },
  {
    "value": 15,
    "name": "Jharkhand"
  },
  {
    "value": 16,
    "name": "Karnataka"
  },
  {
    "value": 17,
    "name": "Kerala"
  },
  {
    "value": 18,
    "name": "Ladakh"
  },
  {
    "value": 19,
    "name": "Lakshadweep"
  },
  {
    "value": 20,
    "name": "Madhya Pradesh"
  },
  {
    "value": 21,
    "name": "Maharashtra"
  },
  {
    "value": 22,
    "name": "Manipur"
  },
  {
    "value": 23,
    "name": "Meghalaya"
  },
  {
    "value": 24,
    "name": "Mizoram"
  },
  {
    "value": 25,
    "name": "Nagaland"
  },
  {
    "value": 26,
    "name": "Odisha"
  },
  {
    "value": 27,
    "name": "Puducherry"
  },
  {
    "value": 28,
    "name": "Punjab"
  },
  {
    "value": 29,
    "name": "Rajasthan"
  },
  {
    "value": 30,
    "name": "Sikkim"
  },
  {
    "value": 31,
    "name": "Tamil Nadu"
  },
  {
    "value": 32,
    "name": "Telangana"
  },
  {
    "value": 33,
    "name": "Tripura"
  },
  {
    "value": 34,
    "name": "Uttar Pradesh"
  },
  {
    "value": 35,
    "name": "Uttarakhand"
  },
  {
    "value": 36,
    "name": "West Bengal"
  }
]
